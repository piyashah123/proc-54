import React, { Component } from 'react';
import { Button, View, Text } from 'react-native';


class AnyButton extends Component {
  displayAlert=()=>{
    alert("you click the button")
  }

  render(){
    return(
      <Button color="red" color={this.props.color} onPress={this.displayAlert} title="Click Me"/>

    )
  }
}

export default class App extends Component {
  render() {
    return (
      <View style={{marginTop: 100}}>
        <AnyButton color="purple" />
        <Text>My First React Component</Text>
      </View>
    );
  }
}